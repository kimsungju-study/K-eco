package com.example.firebaseregister2;

import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class RestApi2 extends AppCompatActivity {

    private TextView responseTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restapi2);

        responseTextView = findViewById(R.id.responseTextView);

        // Execute the API request in the background
        new ApiRequestTask().execute();
    }

    private class ApiRequestTask extends AsyncTask<Void, Void, String> {

        @Override
        protected String doInBackground(Void... params) {
            try {
                // API endpoint URL
                URL url = new URL("http://211.218.104.229:5000/predict");

                // HttpURLConnection setup
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Content-Type", "application/json");

                // POST data
                String postData = "{\"key1\":\"value1\", \"key2\":\"value2\"}";

                // Send POST data
                connection.setDoOutput(true);
                DataOutputStream outputStream = new DataOutputStream(connection.getOutputStream());
                outputStream.write(postData.getBytes(StandardCharsets.UTF_8));
                outputStream.flush();
                outputStream.close();

                // Check response code
                int responseCode = connection.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    // Read response data
                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    String line;
                    StringBuilder response = new StringBuilder();
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    reader.close();

                    // Return the response data
                    return response.toString();
                } else {
                    // Return error message
                    return "Error: " + responseCode;
                }
            } catch (Exception e) {
                e.printStackTrace();
                // Return error message
                return "Error: " + e.getMessage();
            }
        }

        @Override
        protected void onPostExecute(String result) {
            // Update the TextView with the response
            responseTextView.setText(result);
        }
    }
}
