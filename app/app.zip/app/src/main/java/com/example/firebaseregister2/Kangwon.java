package com.example.firebaseregister2;

public class Kangwon {
    private String profile;
    private String data_bak_menu_1;
    private int data_bak_tickets;
    private int data_bup_tickets;
    private String data_dup_menu_1;
    private String data_dup_menu_2;
    private String data_dup_menu_3;
    private String data_dup_menu_4;
    private String data_sp_menu_1;
    private String data_sp_menu_2;
    private int foodwaste;
    private String day;

    private String date;


    public String getProfile() {
        return profile;
    }

    public void setProfile(String profile) {
        this.profile = profile;
    }

    public String getData_bak_menu_1() {
        return data_bak_menu_1;
    }

    public void setData_bak_menu_1(String data_bak_menu_1) {
        this.data_bak_menu_1 = data_bak_menu_1;
    }

    public int getData_bak_tickets() {
        return data_bak_tickets;
    }

    public void setData_bak_tickets(int data_bak_tickets) {
        this.data_bak_tickets = data_bak_tickets;
    }

    public int getData_bup_tickets() {
        return data_bup_tickets;
    }

    public void setData_bup_tickets(int data_bup_tickets) {
        this.data_bup_tickets = data_bup_tickets;
    }

    public String getData_dup_menu_1() {
        return data_dup_menu_1;
    }

    public void setData_dup_menu_1(String data_dup_menu_1) {
        this.data_dup_menu_1 = data_dup_menu_1;
    }

    public String getData_dup_menu_2() {
        return data_dup_menu_2;
    }

    public void setData_dup_menu_2(String data_dup_menu_2) {
        this.data_dup_menu_2 = data_dup_menu_2;
    }

    public String getData_dup_menu_3() {
        return data_dup_menu_3;
    }

    public void setData_dup_menu_3(String data_dup_menu_3) {
        this.data_dup_menu_3 = data_dup_menu_3;
    }

    public String getData_dup_menu_4() {
        return data_dup_menu_4;
    }

    public void setData_dup_menu_4(String data_dup_menu_4) {
        this.data_dup_menu_4 = data_dup_menu_4;
    }

    public String getData_sp_menu_1() {
        return data_sp_menu_1;
    }

    public void setData_sp_menu_1(String data_sp_menu_1) {
        this.data_sp_menu_1 = data_sp_menu_1;
    }

    public String getData_sp_menu_2() {
        return data_sp_menu_2;
    }

    public void setData_sp_menu_2(String data_sp_menu_2) {
        this.data_sp_menu_2 = data_sp_menu_2;
    }

    public int getFoodwaste() {
        return foodwaste;
    }

    public void setFoodwaste(int foodwaste) {
        this.foodwaste = foodwaste;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getDate() {return date;}

    public void setDate(String date) {this.date = date;}


}